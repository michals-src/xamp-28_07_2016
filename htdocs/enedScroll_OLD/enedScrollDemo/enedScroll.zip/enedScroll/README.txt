THANKS FOR PURCHASE ENEDSCROLL !

Let's include enedscroll.min.js file to your project 
and will start create amazing things with your website.
You can find out enedscroll.min.js and enedscroll.js 
in js/ folder. For proper operation, plugin need only 
file .js. 

Open examples in demos/ folder and look how it is works. 

Let the fun begin.

Instalation
  -minifed file
    <script type="text/javascript" src="js/enedscroll.min.js"></script>
  -normal file
    <script type="text/javascript" src="js/enedscroll.js"></script>

Use
  Make sure you use jQuery.
  Create .js file.
  Now read documentation on http://enedscroll.eu/documentation.php
  Congratulations ! Now you can create animations !

* Name: enedScroll Plugin
* Author: Cameolon
* Tags: jquery, enedScroll, scroll, 
* Url: http://enedscroll.eu/
* Docs: http://enedscroll.eu/documentation.php
* License: read LICENSE
  
  